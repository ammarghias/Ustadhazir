package com.example.mechanic

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
