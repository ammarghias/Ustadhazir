import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
// import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:mechanic/telas/servicespage%20copy.dart';

import 'dart:io';

import 'package:url_launcher/url_launcher.dart';

class sett extends StatefulWidget {
  const sett({Key? key}) : super(key: key);

  @override
  State<sett> createState() => _settState();
}

class _settState extends State<sett> {
  TextEditingController _controllerDestino =
      TextEditingController(text: "av. tiradentes, 380 - Maringa PR");

  @override
  void initState() {
    super.initState();
    getUserCurrentLocation();
  }

  bool ty = false;
  String dropdownValue = list.first;
  Future<Position> getUserCurrentLocation() async {
    await Geolocator.requestPermission()
        .then((value) {})
        .onError((error, stackTrace) async {
      await Geolocator.requestPermission();
      print("ERROR" + error.toString());
    });
    return await Geolocator.getCurrentPosition();
  }

  bool _tipoUsuario = false;
  @override
  Widget build(BuildContext context) {
    TextEditingController bikeController = TextEditingController();
    TextEditingController carController = TextEditingController();
    TextEditingController busController = TextEditingController();
    TextEditingController truckController = TextEditingController();
    String bike, bus, truck, car;
    CollectionReference users = FirebaseFirestore.instance.collection('users');
    final Stream<QuerySnapshot> _usersStream =
        FirebaseFirestore.instance.collection('users').snapshots();
    Completer<GoogleMapController> _controller = Completer();
    // on below line we have specified camera position

    // on below line we have created the list of markers
    final List<Marker> _markers = <Marker>[
      Marker(
          markerId: MarkerId('1'),
          position: LatLng(20.42796133580664, 75.885749655962),
          infoWindow: InfoWindow(
            title: 'My Position',
          )),
    ];

    // created method for getting user current location
    Future<Position> getUserCurrentLocation() async {
      await Geolocator.requestPermission()
          .then((value) {})
          .onError((error, stackTrace) async {
        await Geolocator.requestPermission();
        print("ERROR" + error.toString());
      });
      return await Geolocator.getCurrentPosition();
    }

    return Scaffold(
      appBar: AppBar(
        title: Text("Setting Dashboard"),
        // actions: [
        //   Padding(
        //     padding: EdgeInsets.only(bottom: 10),
        //     child: Row(
        //       children: [
        //         Text("Open"),
        //         Switch(
        //             value: _tipoUsuario,
        //             onChanged: (valor) {
        //               setState(() {
        //                 _tipoUsuario = valor;
        //                 if (valor) {
        //                   _tipoUsuario = valor;
        //                   CollectionReference users =
        //                       FirebaseFirestore.instance.collection('users');
        //                   users
        //                       .doc(FirebaseAuth.instance.currentUser!.uid)
        //                       .update({
        //                         // John Doe
        //                         'booking': 0, // John Doe
        //                       })
        //                       .then((value) => print("User Added"))
        //                       .catchError((error) {
        //                         print("Failed to add user: $error");
        //                       });
        //                 } else {
        //                   _tipoUsuario = valor;
        //                   CollectionReference users =
        //                       FirebaseFirestore.instance.collection('users');
        //                   users
        //                       .doc(FirebaseAuth.instance.currentUser!.uid)
        //                       .update({
        //                         // John Doe
        //                         'booking': 1, // John Doe
        //                       })
        //                       .then((value) => print("User Added"))
        //                       .catchError((error) {
        //                         print("Failed to add user: $error");
        //                       });
        //                 }
        //               });
        //             }),
        //         Text("Close"),
        //       ],
        //     ),
        //   ),
        // ],
      ),
      body: SingleChildScrollView(
        child: Container(
          height: 600,
          child: StreamBuilder<QuerySnapshot>(
            stream: _usersStream,
            builder:
                (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
              if (snapshot.hasError) {
                return Text(
                  'Something went wrong',
                  style: TextStyle(color: Colors.black),
                );
              }

              if (snapshot.connectionState == ConnectionState.waiting) {
                return Text("Loading", style: TextStyle(color: Colors.black));
              }

              return ListView(
                children: snapshot.data!.docs.map((DocumentSnapshot document) {
                  Map<String, dynamic> data =
                      document.data()! as Map<String, dynamic>;

                  return Column(children: [
                    if (FirebaseAuth.instance.currentUser!.email ==
                        data['Email'])
                      Column(
                        children: [
                          Text("services"),
                          Container(
                            child: Column(
                              children: [
                                Text(
                                    "your current location will be used as your shop location "),
                                Text('bike price'),
                                Padding(
                                  padding: EdgeInsets.all(8.0),
                                  child: TextField(
                                      controller: bikeController,
                                      decoration: InputDecoration(
                                        border: OutlineInputBorder(),
                                        // labelText: 'bike price',
                                        hintText: data['bike'],
                                      )),
                                ),
                                Text('car price'),
                                Padding(
                                  padding: EdgeInsets.all(8.0),
                                  child: TextField(
                                      controller: carController,
                                      decoration: InputDecoration(
                                        border: OutlineInputBorder(),
                                        // labelText: 'car price',
                                        hintText: data['car'],
                                      )),
                                ),
                                Text('bus price'),
                                Padding(
                                  padding: EdgeInsets.all(8.0),
                                  child: TextField(
                                      controller: busController,
                                      decoration: InputDecoration(
                                        border: OutlineInputBorder(),
                                        // labelText: 'bus price',
                                        hintText: data['bus'],
                                      )),
                                ),
                                Text('Truck price'),
                                Padding(
                                  padding: EdgeInsets.all(8.0),
                                  child: TextField(
                                      controller: truckController,
                                      decoration: InputDecoration(
                                        border: OutlineInputBorder(),
                                        // labelText: 'Truck price',
                                        hintText: data['truck'],
                                      )),
                                ),
                                Padding(
                                    padding:
                                        EdgeInsets.only(top: 16, bottom: 10),
                                    child: ElevatedButton(
                                      style: ElevatedButton.styleFrom(
                                          primary: Colors.green,
                                          padding: EdgeInsets.fromLTRB(
                                              32, 16, 32, 16)),
                                      onPressed: () {
                                        getUserCurrentLocation()
                                            .then((value) => {
                                                  FirebaseFirestore.instance
                                                      .collection('users')
                                                      .doc(FirebaseAuth.instance
                                                          .currentUser!.uid)
                                                      .update({
                                                        'bike': bikeController
                                                            .text, // John Doe
                                                        'bus': busController
                                                            .text, // John Doe
                                                        'truck': truckController
                                                            .text, // John Doe
                                                        'car': carController
                                                            .text, // John Doe
                                                      })
                                                      .then((value) =>
                                                          print("User Added"))
                                                      .catchError((error) {
                                                        print(
                                                            "Failed to add user: $error");
                                                      })
                                                });
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(SnackBar(
                                                content: Text("Updated")));
                                      },
                                      child: Text(
                                        "Update",
                                        style: TextStyle(
                                            color: Colors.white, fontSize: 20),
                                      ),
                                    )),
                                Padding(
                                    padding:
                                        EdgeInsets.only(top: 16, bottom: 10),
                                    child: ElevatedButton(
                                      style: ElevatedButton.styleFrom(
                                          primary: Colors.green,
                                          padding: EdgeInsets.fromLTRB(
                                              32, 16, 32, 16)),
                                      onPressed: () {
                                        getUserCurrentLocation()
                                            .then((value) => {
                                                  FirebaseFirestore.instance
                                                      .collection('users')
                                                      .doc(FirebaseAuth.instance
                                                          .currentUser!.uid)
                                                      .update({
                                                        // John Doe
                                                        'lang': value
                                                            .latitude, // John Doe
                                                        'long': value
                                                            .longitude, // John Doe
                                                        // John Doe
                                                        // John Doe
                                                      })
                                                      .then((value) =>
                                                          print("User Added"))
                                                      .catchError((error) {
                                                        print(
                                                            "Failed to add user: $error");
                                                      })
                                                });
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(SnackBar(
                                                content:
                                                    Text("Location Updated")));
                                      },
                                      child: Text(
                                        "Location Update",
                                        style: TextStyle(
                                            color: Colors.white, fontSize: 20),
                                      ),
                                    )),
                              ],
                            ),
                          )
                        ],
                      ),
                  ]);
                }).toList(),
              );
            },
          ),
        ),
      ),
    );
  }
}
