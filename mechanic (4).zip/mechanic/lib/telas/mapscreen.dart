import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_database/firebase_database.dart';

import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
// import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:mechanic/telas/mchbooking.dart';

import 'dart:io';

import 'package:url_launcher/url_launcher.dart';

class PainelPassageiro extends StatefulWidget {
  final String se, ty;
  const PainelPassageiro({Key? key, required this.se, required this.ty})
      : super(key: key);

  @override
  State<PainelPassageiro> createState() => _PainelPassageiroState();
}

Future<Position> getUserCurrentLocation() async {
  await Geolocator.requestPermission()
      .then((value) {})
      .onError((error, stackTrace) async {
    await Geolocator.requestPermission();
    print("ERROR" + error.toString());
  });

  return await Geolocator.getCurrentPosition();
}

class _PainelPassageiroState extends State<PainelPassageiro> {
  TextEditingController _controllerDestino =
      TextEditingController(text: "av. tiradentes, 380 - Maringa PR");
  double lat = 00, lon = 00;
  @override
  void initState() {
    super.initState();
    getUserCurrentLocation()
        .then((value) => {lat = value.latitude, lon = value.longitude});
    print("ghghgh" + lat.toString() + lon.toString());
  }

  static final CameraPosition _kGoogle = const CameraPosition(
    target: LatLng(20.42796133580664, 80.885749655962),
    zoom: 14.4746,
  );
  @override
  Widget build(BuildContext context) {
    String phon = '';
    CollectionReference users = FirebaseFirestore.instance.collection('mch');
    final Stream<QuerySnapshot> _usersStream =
        FirebaseFirestore.instance.collection('users').snapshots();
    Completer<GoogleMapController> _controller = Completer();
    // on below line we have specified camera position

    // on below line we have created the list of markers
    final List<Marker> _markers = <Marker>[
      Marker(
          markerId: MarkerId('1'),
          position: LatLng(20.42796133580664, 75.885749655962),
          infoWindow: InfoWindow(
            title: 'My Position',
          )),
    ];

    // created method for getting user current location

    return Scaffold(
      appBar: AppBar(
        title: Text("Client Dashboard"),
      ),
      body: Container(
        child: Stack(
          children: [
            Container(
              child: SafeArea(
                // on below line creating google maps
                child: GoogleMap(
                  // on below line setting camera position
                  initialCameraPosition: _kGoogle,
                  // on below line we are setting markers on the map
                  markers: Set<Marker>.of(_markers),
                  // on below line specifying map type.
                  mapType: MapType.normal,
                  // on below line setting user location enabled.
                  myLocationEnabled: true,
                  // on below line setting compass enabled.
                  compassEnabled: true,
                  // on below line specifying controller on map complete.
                  onMapCreated: (GoogleMapController controller) {
                    _controller.complete(controller);
                  },
                ),
              ),
            ),
            // on pressing floating action button the camera will take to user current location
            // FloatingActionButton(
            //   onPressed: () async {
            //     getUserCurrentLocation().then((value) async {
            //       print(value.latitude.toString() +
            //           " " +
            //           value.longitude.toString());
            //       print(
            //           "ammarposition${Geolocator.getCurrentPosition().toString()}" +
            //               value.latitude.toString() +
            //               " " +
            //               value.longitude.toString());

            //       // marker added for current users location
            //       _markers.add(Marker(
            //         markerId: MarkerId("2"),
            //         position: LatLng(value.latitude, value.longitude),
            //         infoWindow: InfoWindow(
            //           title: 'My Current Location',
            //         ),
            //       ));

            //       // specified current users location
            //       CameraPosition cameraPosition = new CameraPosition(
            //         target: LatLng(value.latitude, value.longitude),
            //         zoom: 14,
            //       );

            //       final GoogleMapController controller =
            //           await _controller.future;
            //       controller.animateCamera(
            //           CameraUpdate.newCameraPosition(cameraPosition));
            //       setState(() {});
            //     });
            //   },
            //   child: Icon(Icons.heart_broken),
            // ),

            Positioned(
              right: 0,
              left: 0,
              bottom: 0,
              child: Padding(
                  padding: Platform.isIOS
                      ? EdgeInsets.fromLTRB(20, 10, 20, 25)
                      : EdgeInsets.all(10),
                  child: Container(
                    height: 500,
                    child: StreamBuilder<QuerySnapshot>(
                      stream: _usersStream,
                      builder: (BuildContext context,
                          AsyncSnapshot<QuerySnapshot> snapshot) {
                        if (snapshot.hasError) {
                          return Text(
                            'Something went wrong',
                            style: TextStyle(color: Colors.black),
                          );
                        }

                        if (snapshot.connectionState ==
                            ConnectionState.waiting) {
                          return Text("Loading",
                              style: TextStyle(color: Colors.black));
                        }

                        return ListView(
                          children: snapshot.data!.docs
                              .map((DocumentSnapshot document) {
                            Map<String, dynamic> data =
                                document.data()! as Map<String, dynamic>;
                            print(Text("amm${widget.ty}"));
                            if (data['email'] ==
                                FirebaseAuth.instance.currentUser!.email)
                              phon = data['phone'];
                            return Column(children: [
                              if (data['type'] == 1 &&
                                  data['booking'] == 1 &&
                                  data['service'] == widget.se &&
                                  Geolocator.distanceBetween(data['lang'],
                                          data['long'], lat, lon) <
                                      15000)
                                Container(
                                  height: 100,
                                  width: double.infinity,
                                  color: Colors.white,
                                  child: ListTile(
                                    trailing: Text("RS ${data[widget.ty]}",
                                        style: TextStyle(
                                            fontSize: 20, color: Colors.black)),
                                    // leading: Text("Name",
                                    //     style: TextStyle(
                                    //         fontSize: 20, color: Colors.black)),
                                    title: Text(data['name'],
                                        style: TextStyle(
                                            fontSize: 20, color: Colors.black)),
                                    onTap: () async {
                                      await getUserCurrentLocation().then(
                                          (value) => {
                                                lat = value.latitude,
                                                lon = value.longitude
                                              });
                                      print("latttt" +
                                          lat.toString() +
                                          lon.toString());
                                      var phone;
                                      var collection = FirebaseFirestore
                                          .instance
                                          .collection('users');
                                      users.doc(FirebaseAuth
                                          .instance.currentUser!.uid);
                                      var querySnapshot =
                                          await collection.get();
                                      for (var queryDocumentSnapshot
                                          in querySnapshot.docs) {
                                        Map<String, dynamic> data =
                                            queryDocumentSnapshot.data();
                                        phone = data['phone'];
                                      }
                                      users
                                          .add({
                                            'cEmail': data['Email'],
                                            'Email': FirebaseAuth
                                                .instance.currentUser!.email
                                                .toString(),
                                            'time': TimeOfDay.now().toString(),
                                            'phone': phon, // John Doe
                                            'lat': lat,
                                            'lon': lon,
                                            // Stokes and Sons
                                          })
                                          .then((value) => print("User Added"))
                                          .catchError((error) => print(
                                              "Failed to add user: $error"));
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                CountdownTimerDemo(
                                                  ph: data['phone'],
                                                )),
                                      );
                                      // String googleUrl =
                                      //     'https://www.google.com/maps/search/?api=1&query=${data['lang']},${data['long']}';
                                      // launch(googleUrl);
                                    },
                                  ),
                                ),
                              // GestureDetector(
                              //   onTap: () {},
                              //   child: Padding(
                              //     padding: const EdgeInsets.all(8.0),
                              //     child: Container(
                              //       height: 100,
                              //       width: double.infinity,
                              //       color: Colors.white,
                              //       child: ListTile(
                              //         trailing: Text("12km",
                              //             style: TextStyle(
                              //                 fontSize: 20,
                              //                 color: Colors.black)),
                              //         leading: Text("Name",
                              //             style: TextStyle(
                              //                 fontSize: 20,
                              //                 color: Colors.black)),
                              //         title: Text(data['full_name'],
                              //             style: TextStyle(
                              //                 fontSize: 20,
                              //                 color: Colors.black)),
                              //         subtitle: Text(data['Email'],
                              //             style: TextStyle(
                              //                 fontSize: 20,
                              //                 color: Colors.black)),
                              //         onTap: () {
                              //           users
                              //               .add({
                              //                 'Email': FirebaseAuth
                              //                     .instance.currentUser!.email
                              //                     .toString(),
                              //                 'time':
                              //                     "${TimeOfDay.now().toString()}" // John Doe
                              //                 // Stokes and Sons
                              //               })
                              //               .then(
                              //                   (value) => print("User Added"))
                              //               .catchError((error) => print(
                              //                   "Failed to add user: $error"));
                              //           launch(
                              //               "https://goo.gl/maps/AeFUVJwgRbWFeiKfA");
                              //         },
                              //       ),
                              //     ),
                              //   ),
                              // )
                            ]);
                          }).toList(),
                        );
                      },
                    ),
                  )),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    super.dispose();
    // _streamSubscriptionRequisicoes?.cancel();
    // _streamSubscriptionRequisicoes = null;
  }
}

class MyNavigationBar extends StatefulWidget {
  @override
  _MyNavigationBarState createState() => _MyNavigationBarState();
}

class _MyNavigationBarState extends State<MyNavigationBar> {
  int _selectedIndex = 0;
  static const List<Widget> _widgetOptions = <Widget>[
    PainelPassageiro(
      se: '',
      ty: '',
    ),
    newformc(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: _widgetOptions.elementAt(_selectedIndex),
      ),
      bottomNavigationBar: BottomNavigationBar(
          items: const <BottomNavigationBarItem>[
            BottomNavigationBarItem(
                icon: Icon(Icons.home),
                label: "home",
                backgroundColor: Colors.green),
            // BottomNavigationBarItem(
            //   icon: Icon(Icons.search),

            //   backgroundColor: Colors.yellow
            // ),
            BottomNavigationBarItem(
              icon: Icon(Icons.history),
              label: "History",
              backgroundColor: Colors.green,
            ),
          ],
          type: BottomNavigationBarType.shifting,
          currentIndex: _selectedIndex,
          selectedItemColor: Colors.black,
          iconSize: 40,
          onTap: _onItemTapped,
          elevation: 5),
    );
  }
}

class CountdownTimerDemo extends StatefulWidget {
  final String ph;

  const CountdownTimerDemo({super.key, required this.ph});
  @override
  State<CountdownTimerDemo> createState() => _CountdownTimerDemoState();
}

class _CountdownTimerDemoState extends State<CountdownTimerDemo> {
  // Step 2
  Timer? countdownTimer;
  Duration myDuration = Duration(days: 5);
  void startTimer() {
    countdownTimer =
        Timer.periodic(Duration(seconds: 1), (_) => setCountDown());
  }

  @override
  void initState() {
    super.initState();
    startTimer();
  }

  /// Timer related methods ///
  // Step 3

  // Step 4
  void stopTimer() {
    setState(() => countdownTimer!.cancel());
  }

  // Step 5
  void resetTimer() {
    stopTimer();
    setState(() => myDuration = Duration(days: 5));
  }

  // Step 6
  void setCountDown() {
    final reduceSecondsBy = 1;
    setState(() {
      final seconds = myDuration.inSeconds - reduceSecondsBy;
      if (seconds < 0) {
        countdownTimer!.cancel();
      } else {
        myDuration = Duration(seconds: seconds);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    String strDigits(int n) => n.toString().padLeft(2, '0');

    final days = strDigits(myDuration.inDays); // <-- SEE HERE

    final minutes = strDigits(myDuration.inMinutes.remainder(30));
    final seconds = strDigits(myDuration.inSeconds.remainder(60));

    return Scaffold(
      body: Center(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(
              height: 50,
            ),
            // Step 8
            Text(
              "on its way ",
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                  fontSize: 50),
            ),
            Text(
              '$minutes:$seconds',
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                  fontSize: 50),
            ),
            SizedBox(height: 20),
            Text(
              "Phone number :" + widget.ph,
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                  fontSize: 30),
            ),
            // Step 9
            // ElevatedButton(
            //   onPressed: startTimer,
            //   child: Text(
            //     'Start',
            //     style: TextStyle(
            //       fontSize: 30,
            //     ),
            //   ),
            // ),
            // // Step 10
            // ElevatedButton(
            //   onPressed: () {
            //     if (countdownTimer == null || countdownTimer!.isActive) {
            //       stopTimer();
            //     }
            //   },
            //   child: Text(
            //     'Stop',
            //     style: TextStyle(
            //       fontSize: 30,
            //     ),
            //   ),
            // ),
            // // Step 11
            // ElevatedButton(
            //     onPressed: () {
            //       resetTimer();
            //     },
            //     child: Text(
            //       'Reset',
            //       style: TextStyle(
            //         fontSize: 30,
            //       ),
            //     ))
          ],
        ),
      ),
    );
  }
}
