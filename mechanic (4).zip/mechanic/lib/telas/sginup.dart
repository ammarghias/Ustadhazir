import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:mechanic/telas/servicespage.dart';
import '../model/Usuario.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:mechanic/telas/main_screen.dart';

class Cadastro extends StatefulWidget {
  const Cadastro({Key? key}) : super(key: key);

  @override
  State<Cadastro> createState() => _CadastroState();
}

class _CadastroState extends State<Cadastro> {
  bool valor = false;
  TextEditingController _controllerNome = TextEditingController();
  TextEditingController _controllerEmail = TextEditingController();
  TextEditingController _controllerSenha = TextEditingController();
  TextEditingController _controllerurl = TextEditingController();
  TextEditingController _controllerphon = TextEditingController();
  bool _tipoUsuario = false;
  String _mensagemErro = "";
  bool chk = true;

  _validarCampos() {
    //recuperar dados dos campos
    String nome = _controllerNome.text;
    String email = _controllerEmail.text;
    String senha = _controllerSenha.text;

    //validar campos
    if (nome.isNotEmpty) {
      if (email.isNotEmpty && email.contains("@")) {
        if (senha.isNotEmpty && senha.length > 6) {
          Usuario usuario = Usuario();
          usuario.nome = nome;
          usuario.email = email;
          usuario.senha = senha;

          _cadastrarUsuario(usuario);
        } else {
          setState(() {
            _mensagemErro =
                "Enter password! Please enter more than 6 characters";
          });
        }
      } else {
        setState(() {
          _mensagemErro = "Enter a valid Email";
        });
      }
    } else {
      setState(() {
        _mensagemErro = "Fill in the Name";
      });
    }
  }

  _cadastrarUsuario(Usuario usuario) async {
    bool au = true;

    if (_tipoUsuario) {
      try {
        await FirebaseAuth.instance.createUserWithEmailAndPassword(
            email: usuario.email.toString(),
            password: usuario.senha.toString());
        CollectionReference users =
            FirebaseFirestore.instance.collection('users');
        users
            .doc(FirebaseAuth.instance.currentUser!.uid)
            .set({
              'name': _controllerNome.text,
              'Email': usuario.email, // John Doe
              'phone': _controllerphon.text // John Doe
            })
            .then((value) => print("User Added"))
            .catchError((error) {
              chk = false;
              print("Failed to add user: $error");
            });
      } on FirebaseAuthException catch (e) {
        au = false;
        if (e.code == 'weak-password') {
          print('The password provided is too weak.');
        } else if (e.code == 'email-already-in-use') {
          print('The account already exists for that email.');
        }
      } catch (e) {
        au = false;
        print(e);
      }

      if (au) {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => YellowBird()),
        );
      }
    } else {
      try {
        await FirebaseAuth.instance.createUserWithEmailAndPassword(
            email: usuario.email.toString(),
            password: usuario.senha.toString());
      } on FirebaseAuthException catch (e) {
        au = false;
        if (e.code == 'weak-password') {
          print('The password provided is too weak.');
        } else if (e.code == 'email-already-in-use') {
          print('The account already exists for that email.');
        }
      } catch (e) {
        au = false;
        print(e);
      }

      if (au) {
        CollectionReference users =
            FirebaseFirestore.instance.collection('users');
        users
            .doc(FirebaseAuth.instance.currentUser!.uid)
            .set({
              'Email': usuario.email, // John Doe
              'type': 0, // John Doe
              'booking': 0,
              'phone': _controllerphon.text // John Doe
            })
            .then((value) => print("User Added"))
            .catchError((error) {
              chk = false;
              print("Failed to add user: $error");
            });
        Navigator.pushNamedAndRemoveUntil(context, "/screen", (_) => false);
      }
    }

    // case "passageiro":
    //   Navigator.pushNamedAndRemoveUntil(
    //       context, "/painel-passageiro", (_) => false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Login"),
        backgroundColor: Colors.green,
      ),
      body: Container(
        padding: EdgeInsets.all(16),
        child: Center(
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Padding(
                    padding: EdgeInsets.only(bottom: 32),
                    child: SizedBox(
                      height: 200,
                    )),
                TextField(
                  controller: _controllerNome,
                  autofocus: true,
                  keyboardType: TextInputType.text,
                  style: TextStyle(fontSize: 20),
                  decoration: InputDecoration(
                      contentPadding: EdgeInsets.fromLTRB(32, 16, 32, 16),
                      // fontFamily: "Roboto",
                      hintText: "Type in your name ",
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(6),
                      )),
                ),
                SizedBox(
                  height: 15.0,
                ),
                TextField(
                  controller: _controllerEmail,
                  keyboardType: TextInputType.emailAddress,
                  style: TextStyle(fontSize: 20),
                  decoration: InputDecoration(
                      contentPadding: EdgeInsets.fromLTRB(32, 16, 32, 16),
                      hintText: "E-mail",
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(6),
                      )),
                ),
                SizedBox(
                  height: 15.0,
                ),
                TextField(
                  controller: _controllerSenha,
                  obscureText: true,
                  keyboardType: TextInputType.emailAddress,
                  style: TextStyle(fontSize: 20),
                  decoration: InputDecoration(
                      contentPadding: EdgeInsets.fromLTRB(32, 16, 32, 16),
                      hintText: "Password",
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(6),
                      )),
                ),
                SizedBox(
                  height: 15.0,
                ),
                TextField(
                  controller: _controllerphon,
                  obscureText: false,
                  keyboardType: TextInputType.name,
                  style: TextStyle(fontSize: 20),
                  decoration: InputDecoration(
                      contentPadding: EdgeInsets.fromLTRB(32, 16, 32, 16),
                      hintText: "+92**********",
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(6),
                      )),
                ),
                // TextField(
                //   controller: _controllerurl,
                //   obscureText: true,
                //   keyboardType: TextInputType.url,
                //   style: TextStyle(fontSize: 20),
                //   decoration: InputDecoration(
                //       contentPadding: EdgeInsets.fromLTRB(32, 16, 32, 16),
                //       hintText: "Google Map Link",
                //       filled: true,
                //       fillColor: Colors.white,
                //       border: OutlineInputBorder(
                //         borderRadius: BorderRadius.circular(6),
                //       )),
                // ),
                Padding(
                  padding: EdgeInsets.only(bottom: 10),
                  child: Row(
                    children: [
                      Text("Client"),
                      Switch(
                          value: _tipoUsuario,
                          onChanged: (valor) {
                            setState(() {
                              _tipoUsuario = valor;
                            });
                          }),
                      Text("Mechanic"),
                    ],
                  ),
                ),
                Padding(
                    padding: EdgeInsets.only(top: 16, bottom: 10),
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          primary: Colors.green,
                          padding: EdgeInsets.fromLTRB(32, 16, 32, 16)),
                      onPressed: () {
                        _validarCampos();
                      },
                      child: Text(
                        "Sign Up",
                        style: TextStyle(color: Colors.white, fontSize: 20),
                      ),
                    )),
                Padding(
                  padding: EdgeInsets.only(top: 16),
                  child: Center(
                    child: Text(
                      _mensagemErro,
                      style: TextStyle(color: Colors.red, fontSize: 20),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
