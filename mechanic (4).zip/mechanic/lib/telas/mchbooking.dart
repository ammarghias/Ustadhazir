import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
// import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:mechanic/setting.dart';
import 'package:mechanic/telas/welcome.dart';

import 'dart:io';

import 'package:url_launcher/url_launcher.dart';

class newformc extends StatefulWidget {
  const newformc({Key? key}) : super(key: key);

  @override
  State<newformc> createState() => _newformcState();
}

class _newformcState extends State<newformc> {
  TextEditingController _controllerDestino =
      TextEditingController(text: "av. tiradentes, 380 - Maringa PR");

  @override
  void initState() {
    super.initState();
  }

  bool _tipoUsuario = false;
  @override
  Widget build(BuildContext context) {
    CollectionReference users = FirebaseFirestore.instance.collection('mch');
    final Stream<QuerySnapshot> _usersStream =
        FirebaseFirestore.instance.collection('mch').snapshots();
    Completer<GoogleMapController> _controller = Completer();
    // on below line we have specified camera position

    // on below line we have created the list of markers
    final List<Marker> _markers = <Marker>[
      Marker(
          markerId: MarkerId('1'),
          position: LatLng(20.42796133580664, 75.885749655962),
          infoWindow: InfoWindow(
            title: 'My Position',
          )),
    ];

    // created method for getting user current location
    Future<Position> getUserCurrentLocation() async {
      await Geolocator.requestPermission()
          .then((value) {})
          .onError((error, stackTrace) async {
        await Geolocator.requestPermission();
        print("ERROR" + error.toString());
      });
      return await Geolocator.getCurrentPosition();
    }

    return Scaffold(
      appBar: AppBar(
        title: Text("Booking Dashboard"),
        actions: [
          Padding(
            padding: EdgeInsets.only(bottom: 10),
            child: Row(
              children: [
                Text("Open"),
                Switch(
                    value: _tipoUsuario,
                    onChanged: (valor) {
                      setState(() {
                        _tipoUsuario = valor;
                        if (valor) {
                          _tipoUsuario = valor;
                          CollectionReference users =
                              FirebaseFirestore.instance.collection('users');
                          users
                              .doc(FirebaseAuth.instance.currentUser!.uid)
                              .update({
                                // John Doe
                                'booking': 0, // John Doe
                              })
                              .then((value) => print("User Added"))
                              .catchError((error) {
                                print("Failed to add user: $error");
                              });
                        } else {
                          _tipoUsuario = valor;
                          CollectionReference users =
                              FirebaseFirestore.instance.collection('users');
                          users
                              .doc(FirebaseAuth.instance.currentUser!.uid)
                              .update({
                                // John Doe
                                'booking': 1, // John Doe
                              })
                              .then((value) => print("User Added"))
                              .catchError((error) {
                                print("Failed to add user: $error");
                              });
                        }
                      });
                    }),
                Text("Close"),
                PopupMenuButton(
                    // add icon, by default "3 dot" icon
                    // icon: Icon(Icons.book)
                    itemBuilder: (context) {
                  return [
                    PopupMenuItem<int>(
                      value: 1,
                      child: Text("Settings"),
                    ),
                    PopupMenuItem<int>(
                      value: 2,
                      child: Text("Logout"),
                    ),
                  ];
                }, onSelected: (value) async {
                  if (value == 0) {
                    print("My account menu is selected.");
                  } else if (value == 1) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const sett()),
                    );
                  } else if (value == 2) {
                    await FirebaseAuth.instance.signOut();
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const WelcomeScreen()),
                    );
                  }
                }),
              ],
            ),
          ),
        ],
      ),
      body: Container(
        child: Stack(
          children: [
            Positioned(
              right: 0,
              left: 0,
              bottom: 0,
              child: Padding(
                  padding: Platform.isIOS
                      ? EdgeInsets.fromLTRB(20, 10, 20, 25)
                      : EdgeInsets.all(10),
                  child: Container(
                    height: 600,
                    child: StreamBuilder<QuerySnapshot>(
                      stream: _usersStream,
                      builder: (BuildContext context,
                          AsyncSnapshot<QuerySnapshot> snapshot) {
                        if (snapshot.hasError) {
                          return Text(
                            'Something went wrong',
                            style: TextStyle(color: Colors.black),
                          );
                        }

                        if (snapshot.connectionState ==
                            ConnectionState.waiting) {
                          return Text("Loading",
                              style: TextStyle(color: Colors.black));
                        }

                        return ListView(
                          children: snapshot.data!.docs
                              .map((DocumentSnapshot document) {
                            Map<String, dynamic> data =
                                document.data()! as Map<String, dynamic>;

                            return Column(children: [
                              if (data['cEmail'] ==
                                  FirebaseAuth.instance.currentUser!.email)
                                GestureDetector(
                                  onTap: () {
                                    String googleUrl =
                                        'https://www.google.com/maps/search/?api=1&query=${data['lang']},${data['long']}';
                                    launch(googleUrl);
                                  },
                                  child: Container(
                                    height: 100,
                                    width: double.infinity,
                                    color: Colors.white,
                                    child: ListTile(
                                      leading: Text(data['time'],
                                          style: TextStyle(
                                              fontSize: 15,
                                              color: Colors.black)),
                                      subtitle: Text(data['Email'],
                                          style: TextStyle(
                                              fontSize: 20,
                                              color: Colors.black)),
                                      trailing: Icon(
                                        Icons.directions,
                                        size: 40,
                                      ),
                                    ),
                                  ),
                                ),
                            ]);
                          }).toList(),
                        );
                      },
                    ),
                  )),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    super.dispose();
    // _streamSubscriptionRequisicoes?.cancel();
    // _streamSubscriptionRequisicoes = null;
  }
}
