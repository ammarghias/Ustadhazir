import 'package:flutter/material.dart';
import 'package:mechanic/telas/Home.dart';
import 'package:mechanic/telas/sginup.dart';
import 'package:mechanic/widgets/customized.button.dart';
import 'package:firebase_core/firebase_core.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Firebase.initializeApp();
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 255, 255, 255),
      body: Container(
        child: Column(children: [
          SizedBox(
            height: 60,
          ),
          Row(
            children: [
              Container(
                height: 300,
                width: MediaQuery.of(context).size.width,
                decoration: const BoxDecoration(
                    image:
                        DecorationImage(image: AssetImage("images/mecha.png"))),
              )
            ],
          ),
          SizedBox(
            height: 30,
          ),

          // SizedBox(height: 20, ),
          Row(
            children: [
              CustomizedButton(
                buttonText: "Sign in",
                textColor: Colors.white,
                buttonColor: Colors.green,
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const Home()),
                  );
                },
              ),
            ],
          ),
          Row(
            children: [
              CustomizedButton(
                buttonText: "Sign up",
                textColor: Colors.white,
                buttonColor: Colors.green,
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const Cadastro()),
                  );
                },
              ),
            ],
          )
        ]),
      ),
    );
  }
}
