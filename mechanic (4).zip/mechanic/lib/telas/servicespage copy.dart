import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:mechanic/telas/mchbooking.dart';
import 'package:mechanic/telas/mapscreen.dart';
import 'package:mechanic/widgets/courses_grid.dart';

List<String> list = <String>['Paint', 'Puncture', 'Service', 'fule'];

class newservce extends StatefulWidget {
  final String servicee;

  newservce({super.key, required this.servicee});

  @override
  State<newservce> createState() => _newservceState();
}

class _newservceState extends State<newservce> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getUserCurrentLocation();
  }

  bool ty = false;
  String dropdownValue = list.first;
  Future<Position> getUserCurrentLocation() async {
    await Geolocator.requestPermission()
        .then((value) {})
        .onError((error, stackTrace) async {
      await Geolocator.requestPermission();
      print("ERROR" + error.toString());
    });
    return await Geolocator.getCurrentPosition();
  }

  @override
  Widget build(BuildContext context) {
    TextEditingController bikeController = TextEditingController();
    TextEditingController carController = TextEditingController();
    TextEditingController busController = TextEditingController();
    TextEditingController truckController = TextEditingController();
    String bike, bus, truck, car;
    return Scaffold(
      appBar: AppBar(),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Text("services"),
            Container(
              child: Column(
                children: [
                  Text(
                      "your current location will be used as your shop location "),
                  Padding(
                    padding: EdgeInsets.all(8.0),
                    child: TextField(
                        controller: bikeController,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          labelText: 'bike price',
                        )),
                  ),
                  Padding(
                    padding: EdgeInsets.all(8.0),
                    child: TextField(
                        controller: carController,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          labelText: 'car price',
                        )),
                  ),
                  Padding(
                    padding: EdgeInsets.all(8.0),
                    child: TextField(
                        controller: busController,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          labelText: 'bus price',
                        )),
                  ),
                  Padding(
                    padding: EdgeInsets.all(8.0),
                    child: TextField(
                        controller: truckController,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          labelText: 'Truck price',
                        )),
                  ),
                  Padding(
                      padding: EdgeInsets.only(top: 16, bottom: 10),
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            primary: Colors.green,
                            padding: EdgeInsets.fromLTRB(32, 16, 32, 16)),
                        onPressed: () {
                          getUserCurrentLocation().then((value) => {
                                FirebaseFirestore.instance
                                    .collection('users')
                                    .doc(FirebaseAuth.instance.currentUser!.uid)
                                    .update({
                                      'bike': bikeController.text, // John Doe
                                      'bus': busController.text, // John Doe
                                      'truck': truckController.text, // John Doe
                                      'car': carController.text, // John Doe
                                      'lang': value.latitude, // John Doe
                                      'long': value.longitude, // John Doe
                                      'service': widget.servicee, // John Doe
                                      'booking': 1, // John Doe
                                      'type': 1, // John Doe
                                    })
                                    .then((value) => print("User Added"))
                                    .catchError((error) {
                                      print("Failed to add user: $error");
                                    })
                              });
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => newformc()),
                          );
                        },
                        child: Text(
                          "Sign Up",
                          style: TextStyle(color: Colors.white, fontSize: 20),
                        ),
                      )),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
