import 'package:flutter/material.dart';
import 'package:mechanic/telas/mapscreen.dart';
import 'package:mechanic/widgets/courses_grid.dart';

const List<String> list = <String>['Paint', 'Puncture', 'Service', 'fule'];

class YellowBird extends StatefulWidget {
  @override
  State<YellowBird> createState() => _YellowBirdState();
}

class _YellowBirdState extends State<YellowBird> {
  bool ty = false;
  String dropdownValue = list.first;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Column(
        children: [
          Text("services"),
          const CourseGridsginup(),
          Container(
            child: Column(
              children: [],
            ),
          )
        ],
      ),
    );
  }
}
