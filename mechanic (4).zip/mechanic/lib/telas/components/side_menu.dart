import 'package:flutter/material.dart';
import 'package:ternav_icons/ternav_icons.dart';

import '../../constant.dart';
import 'package:mechanic/telas/main_screen.dart';
import 'package:mechanic/telas/sginup.dart';

import 'package:mechanic/telas/mapscreen.dart';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:mechanic/telas/welcome.dart';

import '../olddashbord.dart';

class SideMenu extends StatelessWidget {
  const SideMenu({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final _auth = FirebaseAuth.instance;
    return Drawer(
      // width: MediaQuery.of(context).size.width / 1.5,
      //  double pixelRatio = MediaQuery.of(context).devicePixelRatio;
      child: ListView(
        shrinkWrap: true,
        children: [
          SizedBox(
            height: 100,
            child: DrawerHeader(
                child: Image.asset(
              "images/logo.png",
            )),
          ),
          DrawerListTile(
            icon: TernavIcons.lightOutline.home_2,
            title: "Services",
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const MainScreen()),
              );
            },
          ),
          DrawerListTile(
            icon: TernavIcons.lightOutline.menu,
            title: "Book a Mechanic",
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => const PainelPassageiro(
                          se: '',
                          ty: '',
                        )),
              );
            },
          ),
          // DrawerListTile(
          //   icon: TernavIcons.lightOutline.folder,
          //   title: "Payment",
          //   onTap: () {},
          // ),

          const SizedBox(
            height: 10,
          ),

          DrawerListTile(
            icon: TernavIcons.lightOutline.settings,
            title: "Logout",
            onTap: () async {
              await FirebaseAuth.instance.signOut();
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const WelcomeScreen()),
              );
              // _auth.signOut();
              // Navigator.pushNamedAndRemoveUntil(context, "/", (_) => false);
              // _deslogarUsuario();
              // Navigator.pop(context);
            },
          ),
          // const SizedBox(
          //   height: 10,
          // ),
          // Image.asset(
          //   "images/help.png",
          //   height: 150,
          // ),
          // const SizedBox(
          //   height: 10,
          // ),
          //
        ],
      ),
    );
  }

  void _deslogarUsuario() {}
}

class DrawerListTile extends StatelessWidget {
  const DrawerListTile({
    Key? key,
    required this.icon,
    required this.title,
    required this.onTap,
  }) : super(key: key);
  final IconData icon;
  final String title;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTap,
      horizontalTitleGap: 0,
      leading: Icon(
        icon,
        color: Colors.grey,
        size: 18,
      ),
      title: Text(
        title,
        style: const TextStyle(color: Colors.grey),
      ),
    );
  }
}
