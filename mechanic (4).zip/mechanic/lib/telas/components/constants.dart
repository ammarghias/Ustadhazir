import 'package:flutter/material.dart';

const kPrimaryColor = Color(0xFFF83D5B);
const kBackgroundColor = Color(0xFFFFFFFF);
const kTextColor = Color(0xFF6E6E6E);
