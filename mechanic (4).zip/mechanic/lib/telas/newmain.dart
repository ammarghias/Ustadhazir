import 'package:firebase_core/firebase_core.dart';
import 'package:mechanic/telas/components/chart_container.dart';
import 'package:mechanic/widgets/activity_header.dart';
import 'package:mechanic/widgets/bar_chart.dart';
import 'package:mechanic/widgets/courses_grid.dart';
import 'package:mechanic/widgets/planing_grid.dart';
// import 'package:mechanic/widgets/statistics_grid.dart';
import 'package:flutter/material.dart';

import '../constant.dart';
import '../widgets/planing_header.dart';
import 'components/side_menu.dart';

class ewmain extends StatelessWidget {
  final String se;
  const ewmain({Key? key, required this.se}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.transparent,
        iconTheme: const IconThemeData(color: Colors.grey, size: 28),
        actions: [
          IconButton(
            onPressed: () {},
            icon: const Icon(
              Icons.search,
              color: Colors.grey,
            ),
          ),
          IconButton(
            onPressed: () {},
            icon: const Icon(
              Icons.notifications,
              color: Colors.grey,
            ),
          ),
          Container(
            margin: const EdgeInsets.only(top: 5, right: 16, bottom: 5),
            child: const CircleAvatar(
              backgroundImage: AssetImage("images/mechanic.png"),
            ),
          )
        ],
      ),
      drawer: const SideMenu(),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(
                height: 15,
              ),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: const [
                  Text(
                    "Vehicle Category",
                    style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
                  ),
                  Text(
                    "View All",
                    style: TextStyle(color: Colors.green),
                  ),
                ],
              ),
              const SizedBox(
                height: 10,
              ),
              CourseGridnnew(
                se: se,
              ),
              const SizedBox(
                height: 20,
              ),
              // const PlaningHeader(),
              // const SizedBox(
              //   height: 15,
              // ),
              // const PlaningGrid(),
              // const SizedBox(
              //   height: 15,
              // ),
              // const Text(
              //   "Statistics",
              //   style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              // ),
              const SizedBox(
                height: 15,
              ),

              // const StatisticsGrid(),
              // const SizedBox(
              //   height: 15,
              // ),
              // const ActivityHeader(),
              // const ChartContainer(chart: BarChartContent())
            ],
          ),
        ),
      ),
    );
  }
}
