import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:mechanic/telas/components/chart_container.dart';
import 'package:mechanic/telas/welcome.dart';
import 'package:mechanic/widgets/activity_header.dart';
import 'package:mechanic/widgets/bar_chart.dart';
import 'package:mechanic/widgets/courses_grid.dart';
import 'package:mechanic/widgets/planing_grid.dart';
// import 'package:mechanic/widgets/statistics_grid.dart';
import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import '../constant.dart';
import '../setting.dart';
import '../widgets/planing_header.dart';
import 'components/side_menu.dart';

class MainScreen extends StatelessWidget {
  const MainScreen({Key? key}) : super(key: key);
// Future <void> _getUserName(){
//   .collection()FirebaseFirebaseAuthFirebaseAuth.instance.currentUser().uid.get())
//   .then()()value{}
//     setState((){

//     }

// }
  @override
  Widget build(BuildContext context) {
    Widget image_carousel = new Container(
        height: 300.0,
        child: CarouselSlider(
          // height: 400.0,
          items: [
            'https://thehub.nrma.com.au/sites/blog/files/styles/article_banner/public/banner/Green_Car%20%281%29.jpg?itok=gZs1oFXH',
            'https://static.vecteezy.com/system/resources/thumbnails/006/763/501/small/high-speed-car-banner-template-with-glowing-low-poly-graphic-car-vector.jpg',
            'https://static.vecteezy.com/system/resources/previews/005/731/390/non_2x/car-insurance-or-security-banner-concept-check-mark-on-green-shield-sign-with-automobile-transport-protection-and-safety-advertising-design-auto-vehicle-guard-service-illustration-vector.jpg',
            'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQiaHZ1V1ATrtQIgi6k7ANZnL-8P5e21qrRgw&usqp=CAU'
          ].map((i) {
            return Builder(
              builder: (BuildContext context) {
                return Container(
                    width: MediaQuery.of(context).size.width,
                    margin: EdgeInsets.symmetric(horizontal: 5.0),
                    decoration: BoxDecoration(color: Colors.amber),
                    child: GestureDetector(
                        child: Image.network(i, fit: BoxFit.fill),
                        onTap: () {
                          // Navigator.push<Widget>(
                          //   context,
                          //   MaterialPageRoute(
                          //     builder: (context) => ImageScreen(i),
                          //   ),
                          // );
                        }));
              },
            );
          }).toList(),
          options: CarouselOptions(
            autoPlay: true,
            enableInfiniteScroll: true,
            height: 200,
            viewportFraction: 1.0,
            enlargeCenterPage: false,
            aspectRatio: 1 / 1.3,
            onPageChanged: (index, reason) {
              // postController.tradeImagesIndex(index);
              // postController.carouselController.nextPage();
            },
          ),
        ));
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.transparent,
        iconTheme: const IconThemeData(color: Colors.grey, size: 28),
        actions: [
          IconButton(
            onPressed: () {},
            icon: const Icon(
              Icons.search,
              color: Colors.grey,
            ),
          ),
          IconButton(
            onPressed: () {},
            icon: const Icon(
              Icons.notifications,
              color: Colors.grey,
            ),
          ),
          Container(
            margin: const EdgeInsets.only(top: 5, right: 16, bottom: 5),
            child: const CircleAvatar(
              backgroundImage: AssetImage("images/mechanic.png"),
            ),
          ),
          PopupMenuButton(
              // add icon, by default "3 dot" icon
              // icon: Icon(Icons.book)
              itemBuilder: (context) {
            return [
              PopupMenuItem<int>(
                value: 2,
                child: Text("Logout"),
              ),
            ];
          }, onSelected: (value) async {
            if (value == 0) {
              print("My account menu is selected.");
            } else if (value == 1) {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const sett()),
              );
            } else if (value == 2) {
              await FirebaseAuth.instance.signOut();
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const WelcomeScreen()),
              );
            }
          }),
        ],
      ),
      drawer: const SideMenu(),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              RichText(
                text: const TextSpan(
                  text: "Hello ",
                  style: TextStyle(color: Colors.green, fontSize: 20),
                  children: [
                    TextSpan(
                      text: " welcome to Ustad Hazir!",
                    ),
                  ],
                ),
              ),
              const SizedBox(
                height: 15,
              ),
              image_carousel,
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: const [
                  Text(
                    "Our Services",
                    style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
                  ),
                  Text(
                    "View All",
                    style: TextStyle(color: Colors.green),
                  ),
                ],
              ),
              const SizedBox(
                height: 10,
              ),
              const CourseGrid(),
              const SizedBox(
                height: 20,
              ),
              // const PlaningHeader(),
              // const SizedBox(
              //   height: 15,
              // ),
              // const PlaningGrid(),
              // const SizedBox(
              //   height: 15,
              // ),
              // const Text(
              //   "Statistics",
              //   style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              // ),
              const SizedBox(
                height: 15,
              ),

              // const StatisticsGrid(),
              // const SizedBox(
              //   height: 15,
              // ),
              // const ActivityHeader(),
              // const ChartContainer(chart: BarChartContent())
            ],
          ),
        ),
      ),
    );
  }
}
