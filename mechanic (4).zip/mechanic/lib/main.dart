import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:mechanic/telas/Home.dart';
import 'package:mechanic/telas/mchbooking.dart';
import 'package:mechanic/telas/main_screen.dart';
import 'package:mechanic/telas/welcome.dart';
import 'package:animated_splash_screen/animated_splash_screen.dart';
import 'Rotas.dart';

final ThemeData temaPadrao = ThemeData(
  colorScheme: ColorScheme.fromSwatch().copyWith(
    primary: const Color(0xff37474f),
    secondary: const Color(0xff546e7a),
  ),
);

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  bool ik = false;
  if (FirebaseAuth.instance.currentUser != null) {
    final data = await FirebaseFirestore.instance
        .collection('users')
        .doc(FirebaseAuth.instance.currentUser!.uid)
        .get();
    DocumentSnapshot snapshot = data;
    ik = data['type'] == 1 ? true : false;
  }

  runApp(MaterialApp(
    title: "Mechanic Finder",
    home: AnimatedSplashScreen(
      splash: Image(
        image: AssetImage('images/logo.png'),
      ),
      duration: 3000,
      backgroundColor: Colors.lightGreenAccent,
      splashTransition: SplashTransition.fadeTransition,
      nextScreen: FirebaseAuth.instance.currentUser != null
          ? ik
              ? newformc() //
              : MainScreen()
          : WelcomeScreen(),
    ),
    theme: temaPadrao,
    initialRoute: "/",
    onGenerateRoute: Rotas.gerarRotas,
    debugShowCheckedModeBanner: false,
  ));
}
