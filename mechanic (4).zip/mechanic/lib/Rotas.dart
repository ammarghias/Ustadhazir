import 'package:flutter/material.dart';
import 'package:mechanic/telas/sginup.dart';

import 'package:mechanic/telas/Home.dart';
import 'package:mechanic/telas/olddashbord.dart';
import 'package:mechanic/telas/mapscreen.dart';
import 'package:mechanic/telas/main_screen.dart';

class Rotas {
  static Route<dynamic>? gerarRotas(RouteSettings settings) {
    final args = settings.arguments;

    switch (settings.name) {
      case "/":
        return MaterialPageRoute(builder: (_) => Home());
      case "/cadastro":
        return MaterialPageRoute(builder: (_) => Cadastro());
      case "/painel-motorista":
        return MaterialPageRoute(builder: (_) => PainelMotorista());
      case "/painel-passageiro":
        return MaterialPageRoute(
            builder: (_) => PainelPassageiro(
                  se: '',
                  ty: '',
                ));
      case "/screen":
        return MaterialPageRoute(builder: (_) => MainScreen());
      // case "/corrida":
      //   return MaterialPageRoute(builder: (_) => Corrida(args as String));
      default:
        _erroRota();
    }
    return null;
  }

  static Route<dynamic>? _erroRota() {
    return MaterialPageRoute(builder: (_) {
      return Scaffold(
        appBar: AppBar(
          title: Text("Screen Not Found!"),
        ),
        body: Center(
          child: Text("Screen Not Found!"),
        ),
      );
    });
  }
}
