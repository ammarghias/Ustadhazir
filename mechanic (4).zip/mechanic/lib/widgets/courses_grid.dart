import 'package:mechanic/data/data.dart';
import 'package:flutter/material.dart';
import 'package:mechanic/model/constant.dart';
import 'package:mechanic/model/course_model.dart';
import 'package:mechanic/telas/mapscreen.dart';
import 'package:mechanic/telas/newmain.dart';
import 'package:mechanic/telas/servicespage%20copy.dart';
import 'package:percent_indicator/percent_indicator.dart';

class CourseGrid extends StatelessWidget {
  const CourseGrid({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
        itemCount: course.length,
        physics: const NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            childAspectRatio: 16 / 7, crossAxisCount: 2, mainAxisSpacing: 20),
        itemBuilder: (context, index) {
          return Padding(
            padding: const EdgeInsets.all(8.0),
            child: GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => ewmain(
                            se: course[index].text,
                          )),
                );
              },
              child: Container(
                decoration: BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage(course[index].backImage),
                      fit: BoxFit.fill),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Text(
                            course[index].text,
                            style: const TextStyle(color: Colors.white),
                          ),
                        ],
                      ),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Image.asset(
                            course[index].imageUrl,
                            height: 10,
                          )
                        ],
                      )
                    ],
                  ),
                ),
              ),
            ),
          );
        });
  }
}

class CourseGridnnew extends StatelessWidget {
  final String se;

  const CourseGridnnew({super.key, required this.se});

  @override
  Widget build(BuildContext context) {
    final List<Course> courseet = [
      Course(
          text: "car",
          lessons: "100",
          imageUrl: "images/pic/c.png",
          percent: 90,
          backImage: "images/box/c.png",
          color: Colors.transparent),
      Course(
          text: "bike",
          lessons: "90",
          imageUrl: "images/pic/b.png",
          percent: 89,
          backImage: "images/box/b.png",
          color: kOrange),
      Course(
          text: "bus",
          lessons: "100",
          imageUrl: "images/pic/bb.png",
          percent: 97,
          backImage: "images/box/bb.png",
          color: kGreen),
      Course(
          text: "truck",
          lessons: "100",
          imageUrl: "images/pic/t.png",
          percent: 75,
          backImage: "images/box/t.png",
          color: Colors.red),
    ];
    return GridView.builder(
        itemCount: course.length,
        physics: const NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            childAspectRatio: 16 / 7, crossAxisCount: 1, mainAxisSpacing: 20),
        itemBuilder: (context, index) {
          return GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => PainelPassageiro(
                          se: se,
                          ty: courseet[index].text,
                        )),
              );
            },
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                    image: AssetImage(course[index].backImage),
                    fit: BoxFit.fill),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Text(
                          courseet[index].text,
                          style: const TextStyle(
                              color: Colors.white, fontSize: 40),
                        ),
                        // Text(
                        //   "Price",
                        //   style: const TextStyle(
                        //       color: Colors.white, fontSize: 30),
                        // ),
                        // Text(
                        //   " Rs ${courseet[index].lessons}",
                        //   style: const TextStyle(
                        //       color: Colors.white, fontSize: 30),
                        // ),
                      ],
                    ),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Image.asset(
                          courseet[index].imageUrl,
                          height: 110,
                        )
                      ],
                    )
                  ],
                ),
              ),
            ),
          );
        });
  }
}

class CourseGridsginup extends StatelessWidget {
  const CourseGridsginup({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
        itemCount: course.length,
        physics: const NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            childAspectRatio: 16 / 7, crossAxisCount: 2, mainAxisSpacing: 20),
        itemBuilder: (context, index) {
          return Padding(
            padding: const EdgeInsets.all(8.0),
            child: GestureDetector(
              onTap: () {
                final String ss = course[index].text;
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => newservce(
                            servicee: "$ss",
                          )),
                );
              },
              child: Container(
                decoration: BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage(course[index].backImage),
                      fit: BoxFit.fill),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Text(
                            course[index].text,
                            style: const TextStyle(color: Colors.white),
                          ),
                        ],
                      ),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Image.asset(
                            course[index].imageUrl,
                            height: 30,
                          )
                        ],
                      )
                    ],
                  ),
                ),
              ),
            ),
          );
        });
  }
}
