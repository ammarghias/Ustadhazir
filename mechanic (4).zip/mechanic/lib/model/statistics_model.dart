class Statistics {
  final String title;
  final String number;

  Statistics({
    required this.title,
    required this.number,
  });
}
